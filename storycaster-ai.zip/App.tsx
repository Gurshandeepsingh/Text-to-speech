
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { StoryInput } from './components/StoryInput';
import { Controls } from './components/Controls';
import { AudioPlayer } from './components/AudioPlayer';
import { Loader } from './components/Loader';
import { generateAudio, translateText } from './services/geminiService';
import { audioBufferToWaveBlob } from './utils/audioUtils';
import type { Genre, Voice, Language } from './types';
import { GENRES, VOICES, LANGUAGES } from './constants';

const App: React.FC = () => {
    const [storyText, setStoryText] = useState<string>('');
    const [genre, setGenre] = useState<Genre>(GENRES[0]);
    const [voice, setVoice] = useState<Voice>(VOICES[0]);
    
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [audioSrc, setAudioSrc] = useState<string | null>(null);
    const [audioFileName, setAudioFileName] = useState<string>('story.wav');

    const [isTranslating, setIsTranslating] = useState<boolean>(false);
    const [translatedAudioSrc, setTranslatedAudioSrc] = useState<string | null>(null);
    const [translatedAudioFileName, setTranslatedAudioFileName] = useState<string>('translated_story.wav');

    const handleGenerateAudio = useCallback(async () => {
        if (!storyText.trim()) {
            setError('Please enter a story to generate audio.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setAudioSrc(null);
        setTranslatedAudioSrc(null);

        try {
            const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            const base64Audio = await generateAudio(storyText, voice.id, genre.prompt);
            const audioBuffer = await audioBufferToWaveBlob(base64Audio, audioContext);
            const url = URL.createObjectURL(audioBuffer);
            setAudioSrc(url);
            setAudioFileName(`${genre.name.toLowerCase().replace(' ', '_')}_story.wav`);
        } catch (e) {
            console.error(e);
            setError('Failed to generate audio. Please check your API key and try again.');
        } finally {
            setIsLoading(false);
        }
    }, [storyText, voice, genre]);

    const handleTranslateAndGenerateAudio = useCallback(async (targetLanguage: Language) => {
        if (!storyText.trim()) {
            setError('Please enter a story to translate.');
            return;
        }
        setIsTranslating(true);
        setError(null);
        setTranslatedAudioSrc(null);

        try {
            const translatedText = await translateText(storyText, targetLanguage.name);
            const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            const base64Audio = await generateAudio(translatedText, voice.id, genre.prompt);
            const audioBuffer = await audioBufferToWaveBlob(base64Audio, audioContext);
            const url = URL.createObjectURL(audioBuffer);
            setTranslatedAudioSrc(url);
            setTranslatedAudioFileName(`${targetLanguage.name.toLowerCase()}_story.wav`);
        } catch (e) {
            console.error(e);
            setError('Failed to translate and generate audio. Please try again.');
        } finally {
            setIsTranslating(false);
        }
    }, [storyText, voice, genre]);

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-900 to-indigo-900 text-gray-200">
            <Header />
            <main className="container mx-auto p-4 md:p-8">
                <div className="bg-gray-800 bg-opacity-50 backdrop-blur-md rounded-2xl shadow-2xl p-6 md:p-8">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <div className="flex flex-col space-y-6">
                            <h2 className="text-2xl font-bold text-indigo-300">1. Craft Your Story</h2>
                            <StoryInput value={storyText} onChange={setStoryText} />
                            <h2 className="text-2xl font-bold text-indigo-300">2. Set the Scene</h2>
                            <Controls
                                genre={genre}
                                onGenreChange={setGenre}
                                voice={voice}
                                onVoiceChange={setVoice}
                                onGenerate={handleGenerateAudio}
                                isDisabled={isLoading || !storyText.trim()}
                            />
                        </div>

                        <div className="flex flex-col space-y-6">
                             <h2 className="text-2xl font-bold text-indigo-300">3. Listen & Share</h2>
                            {isLoading && <Loader message="Casting your story... this may take a moment." />}
                            {error && <div className="text-red-400 bg-red-900 bg-opacity-50 p-4 rounded-lg">{error}</div>}
                            
                            {audioSrc && (
                                <AudioPlayer
                                    title="Original Narration"
                                    audioSrc={audioSrc}
                                    fileName={audioFileName}
                                    isTranslating={isTranslating}
                                    onTranslate={handleTranslateAndGenerateAudio}
                                />
                            )}
                            
                            {isTranslating && !translatedAudioSrc && <Loader message="Translating your story across worlds..." />}

                            {translatedAudioSrc && (
                                <AudioPlayer
                                    title="Translated Narration"
                                    audioSrc={translatedAudioSrc}
                                    fileName={translatedAudioFileName}
                                    isTranslating={false}
                                    onTranslate={() => {}}
                                    isTranslationPlayer={true}
                                />
                            )}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default App;
