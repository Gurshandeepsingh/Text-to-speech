import React, { useState, useRef } from 'react';
import type { Language } from '../types';
import { LANGUAGES } from '../constants';

interface AudioPlayerProps {
    title: string;
    audioSrc: string;
    fileName: string;
    isTranslating: boolean;
    onTranslate: (language: Language) => void;
    isTranslationPlayer?: boolean;
}

const Select: React.FC<{
    label: string;
    value: string;
    options: any[];
    onChange: (selected: any) => void;
    renderOption: (option: any) => string;
    keyField: string;
}> = ({ label, value, options, onChange, renderOption, keyField }) => (
    <div className="flex flex-col space-y-1">
        <label className="text-xs font-medium text-indigo-300">{label}</label>
        <div className="relative">
            <select
                value={value}
                onChange={e => {
                    const selected = options.find(o => o[keyField] === e.target.value);
                    if (selected) onChange(selected);
                }}
                className="w-full appearance-none bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
            >
                {options.map(option => (
                    <option key={option[keyField]} value={option[keyField]}>
                        {renderOption(option)}
                    </option>
                ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
            </div>
        </div>
    </div>
);

export const AudioPlayer: React.FC<AudioPlayerProps> = ({
    title, audioSrc, fileName, isTranslating, onTranslate, isTranslationPlayer = false
}) => {
    const [targetLanguage, setTargetLanguage] = useState<Language>(LANGUAGES[1]); // Default to Spanish

    return (
        <div className="bg-gray-800 p-4 rounded-lg shadow-inner space-y-4 border border-gray-700">
            <div className="flex justify-between items-center">
                <h3 className="font-bold text-lg text-indigo-200">{title}</h3>
                <a
                    href={audioSrc}
                    download={fileName}
                    className="flex items-center text-sm bg-gray-700 hover:bg-gray-600 text-indigo-200 font-semibold py-1 px-3 rounded-full transition-colors duration-300"
                    aria-label={`Download ${fileName}`}
                >
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    Download
                </a>
            </div>
            <audio src={audioSrc} controls className="w-full" />
            
            {!isTranslationPlayer && (
                <div className="border-t border-gray-700 pt-4 space-y-3">
                    <p className="text-sm text-indigo-200 font-semibold">Translate Story</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
                       <Select
                            label="Target Language"
                            value={targetLanguage.id}
                            options={LANGUAGES.filter(l => l.id !== 'en')} // Exclude English
                            onChange={setTargetLanguage}
                            keyField="id"
                            renderOption={(l: Language) => l.name}
                        />
                        <button
                            onClick={() => onTranslate(targetLanguage)}
                            disabled={isTranslating}
                            className="w-full bg-green-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700 disabled:bg-green-900 disabled:text-gray-500 disabled:cursor-not-allowed transition-colors duration-300 flex items-center justify-center text-sm"
                        >
                             <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5h12M9 3v2m1.06 7.124a2.25 2.25 0 003.88 0M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            Translate & Narrate
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};
