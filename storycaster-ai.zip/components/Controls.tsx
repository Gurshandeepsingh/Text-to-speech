import React from 'react';
import type { Genre, Voice } from '../types';
import { GENRES, VOICES } from '../constants';

interface ControlsProps {
    genre: Genre;
    onGenreChange: (genre: Genre) => void;
    voice: Voice;
    onVoiceChange: (voice: Voice) => void;
    onGenerate: () => void;
    isDisabled: boolean;
}

const Select: React.FC<{
    label: string;
    value: string;
    options: any[];
    onChange: (selected: any) => void;
    renderOption: (option: any) => string;
    keyField: string;
}> = ({ label, value, options, onChange, renderOption, keyField }) => (
    <div className="flex flex-col space-y-2">
        <label className="text-sm font-medium text-indigo-200">{label}</label>
        <div className="relative">
            <select
                value={value}
                onChange={e => {
                    const selected = options.find(o => o[keyField] === e.target.value);
                    if (selected) onChange(selected);
                }}
                className="w-full appearance-none bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
                {options.map(option => (
                    <option key={option[keyField]} value={option[keyField]}>
                        {renderOption(option)}
                    </option>
                ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
            </div>
        </div>
    </div>
);

export const Controls: React.FC<ControlsProps> = ({
    genre, onGenreChange, voice, onVoiceChange, onGenerate, isDisabled
}) => {
    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select
                    label="Story Genre / Tone"
                    value={genre.id}
                    options={GENRES}
                    onChange={onGenreChange}
                    keyField="id"
                    renderOption={(g: Genre) => `${g.emoji} ${g.name}`}
                />
                <Select
                    label="Narrator's Voice"
                    value={voice.id}
                    options={VOICES}
                    onChange={onVoiceChange}
                    keyField="id"
                    renderOption={(v: Voice) => `${v.name} (${v.type})`}
                />
            </div>
            <button
                onClick={onGenerate}
                disabled={isDisabled}
                className="w-full flex items-center justify-center bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-900 disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
                 <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.636 5.636a9 9 0 0112.728 0M8.464 15.536a5 5 0 010-7.072"></path></svg>
                Generate Audio
            </button>
        </div>
    );
};
