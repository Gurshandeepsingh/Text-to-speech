import React from 'react';

interface LoaderProps {
    message: string;
}

export const Loader: React.FC<LoaderProps> = ({ message }) => (
    <div className="flex flex-col items-center justify-center space-y-4 p-8 bg-gray-800 bg-opacity-70 rounded-lg">
        <div className="w-12 h-12 border-4 border-t-transparent border-indigo-400 rounded-full animate-spin"></div>
        <p className="text-indigo-200 text-center">{message}</p>
    </div>
);
