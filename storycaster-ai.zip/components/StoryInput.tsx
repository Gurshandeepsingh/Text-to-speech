import React from 'react';

interface StoryInputProps {
    value: string;
    onChange: (value: string) => void;
}

export const StoryInput: React.FC<StoryInputProps> = ({ value, onChange }) => {
    return (
        <textarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Once upon a time in a land far, far away..."
            className="w-full h-64 p-4 bg-gray-900 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300 text-gray-200 placeholder-gray-500 resize-none"
            aria-label="Story text input"
        />
    );
};
