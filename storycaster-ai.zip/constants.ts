import type { Genre, Voice, Language } from './types';

export const GENRES: Genre[] = [
  { id: 'mysterious', name: 'Mysterious', prompt: 'narrated in a suspenseful and mysterious tone', emoji: '🤫' },
  { id: 'adventure', name: 'Adventure', prompt: 'narrated in an energetic and bold tone', emoji: '🤠' },
  { id: 'funny', name: 'Funny', prompt: 'narrated in a playful and lively tone', emoji: '😂' },
  { id: 'romantic', name: 'Romantic', prompt: 'narrated in a soft and emotional tone', emoji: '❤️' },
  { id: 'dramatic', name: 'Dramatic', prompt: 'narrated in an intense and expressive tone', emoji: '🎭' },
];

export const VOICES: Voice[] = [
    { id: 'Kore', name: 'Kore', type: 'Female' },
    { id: 'Puck', name: 'Puck', type: 'Male' },
    { id: 'Charon', name: 'Charon', type: 'Male' },
    { id: 'Zephyr', name: 'Zephyr', type: 'Female' },
    { id: 'Fenrir', name: 'Fenrir', type: 'Male' },
];

export const LANGUAGES: Language[] = [
    { id: 'en', name: 'English' },
    { id: 'es', name: 'Spanish' },
    { id: 'fr', name: 'French' },
    { id: 'de', name: 'German' },
    { id: 'hi', name: 'Hindi' },
    { id: 'it', name: 'Italian' },
    { id: 'ja', name: 'Japanese' },
    { id: 'ko', name: 'Korean' },
    { id: 'pt', name: 'Portuguese' },
];
