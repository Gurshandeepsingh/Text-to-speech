export interface Genre {
  id: string;
  name: string;
  prompt: string;
  emoji: string;
}

export interface Voice {
  id: string;
  name: string;
  type: 'Male' | 'Female';
}

export interface Language {
  id: string;
  name: string;
}
